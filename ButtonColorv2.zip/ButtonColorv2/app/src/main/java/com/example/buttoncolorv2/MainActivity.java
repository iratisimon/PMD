package com.example.buttoncolorv2;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    private GridLayout myGridLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Random random = new Random();
        myGridLayout = (GridLayout) findViewById(R.id.gridLayout);



        for (int i = 1; i <= 17; i++) {
            Button myButton = new Button(this);
            myButton.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            myButton.setId(View.generateViewId());


            // Generar color aleatorio para el fondo
            int color = Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));
            myButton.setBackgroundColor(color);

            // Añadir el listener para cambiar el color a blanco al pulsar
            myButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    myButton.setBackgroundColor(Color.WHITE);
                }
            });
            myGridLayout.addView(myButton);
        }

        // Botón Reset
        Button resetButton = new Button(this);
        resetButton.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        resetButton.setId(View.generateViewId());

        resetButton.setText(R.string.textReset);
        resetButton.setBackgroundColor(Color.WHITE);

        // Acción del botón Reset
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 0; i < myGridLayout.getChildCount() - 1; i++) {
                    Button button = (Button) myGridLayout.getChildAt(i); // Obtiene el botón en la posición i
                    int color = Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)); // Genera un nuevo color aleatorio
                    button.setBackgroundColor(color); // Cambia el color de fondo del botón
                }
            }
        });
        myGridLayout.addView(resetButton);
    }
}