package com.example.llamada;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView mytextView = null;
    private ImageButton myImageButton = null;
    private ImageView myImageView = null;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mytextView = (TextView)  findViewById(R.id.titulo);

        myImageButton = (ImageButton) findViewById(R.id.llamar);
        myImageButton.setOnClickListener(this::onClick);

        myImageView = (ImageView) findViewById(R.id.Walter1);
    }

    private void onClick(View view) {
    myImageButton.setActivated(!myImageButton.isActivated());

        if (myImageButton.isActivated()){
            mytextView.setText(R.string.textLlamando);
            myImageButton.setImageDrawable(getDrawable(R.drawable.colgar_9));
            myImageView.setImageDrawable(getDrawable(R.drawable.walterwhite2_9));
        } else {
            mytextView.setText(R.string.textTerminado);
            myImageButton.setImageDrawable(getDrawable(R.drawable.llamar));
            myImageView.setImageDrawable(getDrawable(R.drawable.walterwhite_9));
        }
    }
}