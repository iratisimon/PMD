package com.example.videojuego;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private TextView textViewMensaje;
    private RadioButton radioFallout;
    private RadioButton radioLOL;
    private RadioButton radioFortnite;
    private RadioButton radioTeam;
    private RadioGroup radioGroup;
    private CheckBox checkBox;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        textViewMensaje = (TextView) findViewById(R.id.textView);
        textViewMensaje.setText(R.string.textMensajeInicial);

        radioFallout = findViewById(R.id.radioFallout);
        radioLOL = findViewById(R.id.radioLOL);
        radioFortnite = findViewById(R.id.radioFortnite);
        radioTeam = findViewById(R.id.radioTeam);

        radioGroup = findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(this::onClickRadioGroup);

        checkBox = (CheckBox) findViewById(R.id.checkBox2);
        checkBox.setOnCheckedChangeListener(this::onClickCheckBox);
    }
    private void onClickRadioGroup(RadioGroup radioGroup, int seleccionado) {
        String mensaje = getString(R.string.textRadioSeleccionado);

        if (radioFallout.isChecked()){
            mensaje += " " + getString(R.string.textFallout) + ".";
        } else if (radioLOL.isChecked()){
            mensaje += " " + getString(R.string.textLOL) + ".";
        } else if (radioFortnite.isChecked()){
            mensaje += " " + getString(R.string.textFortnite) + ".";
        } else if (radioTeam.isChecked()) {
            mensaje += " " + getString(R.string.textTF) + ".";
        }

        textViewMensaje.setText(mensaje);
    }

    private void onClickCheckBox(CompoundButton compoundButton, boolean b) {

        if (checkBox.isChecked()){
            textViewMensaje.setText(getString(R.string.textCheckSeleccionado));
        } else {
            textViewMensaje.setText(getString(R.string.textCheckNoSeleccionado));
        }
    }
}